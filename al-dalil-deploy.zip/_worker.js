// This worker handles routing and static file serving for Cloudflare Pages
addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request));
});

async function handleRequest(request) {
  const url = new URL(request.url);
  let filePath = url.pathname;

  // Default to index.html for root
  if (filePath === '/') {
    filePath = '/index.html';
  }

  // Remove leading slash for file lookup
  filePath = filePath.startsWith('/') ? filePath.substring(1) : filePath;

  // Try to serve the file
  try {
    // Check if the file exists in the KV namespace
    const file = await ASSETS.get(filePath);
    if (file) {
      const contentType = getContentType(filePath);
      return new Response(file, {
        headers: { 'Content-Type': contentType },
      });
    }

    // If file not found, try serving index.html for SPA routing
    const indexFile = await ASSETS.get('index.html');
    if (indexFile) {
      return new Response(indexFile, {
        headers: { 'Content-Type': 'text/html' },
      });
    }
  } catch (e) {
    // Return 404 for any errors
    return new Response('Not Found', { status: 404 });
  }

  // If we get here, return 404
  return new Response('Not Found', { status: 404 });
}

function getContentType(filePath) {
  const extension = filePath.split('.').pop().toLowerCase();
  const mimeTypes = {
    'html': 'text/html',
    'js': 'application/javascript',
    'css': 'text/css',
    'json': 'application/json',
    'png': 'image/png',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'gif': 'image/gif',
    'svg': 'image/svg+xml',
    'ico': 'image/x-icon',
    'webp': 'image/webp',
    'woff': 'font/woff',
    'woff2': 'font/woff2',
    'ttf': 'font/ttf',
    'eot': 'application/vnd.ms-fontobject',
    'otf': 'font/otf',
    'wasm': 'application/wasm'
  };
  
  return mimeTypes[extension] || 'application/octet-stream';
}
